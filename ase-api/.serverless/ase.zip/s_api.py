import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='03difoha',
    application_name='ase',
    app_uid='C5LyGGmP1kf8z0rCyR',
    org_uid='2687c95d-53df-4666-b899-a92f73c459fa',
    deployment_uid='67eda7be-ccfa-40b2-99ef-f9388291da2f',
    service_name='ase',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.5.1',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'ase-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
